Plugin info:



This mod of falcon punch add ganondorf super armor and change the throw trajectory almost in a straight line! I change the direction and add a line of code whit super armor.


Plugin info:

Este mod de Falcon Punch agrega una súper armadura Ganondorf y cambia la trayectoria del lanzamiento casi en línea recta! Cambie la dirección y agrege una línea de código con súper armadura.



Not Wi-Fi safe!
No es seguro con Wi-Fi!


Enjoy!
Disfruta!
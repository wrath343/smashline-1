A modified version of WuBoy's skyline-rs-template to better fit my personal needs. 

Please see https://github.com/WuBoytH/skyline-rs-template
